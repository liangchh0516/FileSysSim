from command import HELP_MSG, CMD, FileSystem
import pickle

PATH = './'
INIT_SAVE_NAME = 'SysInit.pickle'


class SysInit:
    def __init__(self):
        self.sys = FileSystem()
        self.cmd = CMD(self.sys)

    def initialization(self):
        self.cmd.Touch('file1')
        self.cmd.Cat([HELP_MSG, '>', 'file1'])
        self.cmd.Mkdir('dir1')
        self.cmd.Cd('dir1')
        self.cmd.Touch('file2')
        self.cmd.Cat(['This is a test file.\n' * 3, '>', 'file2'])
        self.cmd.Mkdir('file3')
        self.cmd.Cd()
        return self.sys

    def Save(self):
        with open(PATH + INIT_SAVE_NAME, 'wb') as f:
            pickle.dump(self, f)


if __name__ == '__main__':
    print('将制作一个初始化文件，文件名为:', INIT_SAVE_NAME)
    init = SysInit()
    init.Save()
