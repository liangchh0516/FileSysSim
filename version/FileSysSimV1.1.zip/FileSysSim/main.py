from command import Decode, CMD, FileSystem
from init import PATH, INIT_SAVE_NAME, SysInit
import pickle
import time
# import os os.system("cls")


SYS_SAVE_NAME = 'FileSysSim.pickle'


def SaveSys(sys: FileSystem):
    with open(PATH + SYS_SAVE_NAME, 'wb') as f:
        pickle.dump(sys, f)


def LoadSys() -> FileSystem:
    try:
        with open(PATH + SYS_SAVE_NAME, 'rb') as f:
            sys = pickle.load(f)
            return sys
    except FileNotFoundError:
        print('未找到保存的文件系统')
        raise FileNotFoundError


def LoadInit() -> FileSystem:
    try:
        with open(PATH + INIT_SAVE_NAME, 'rb') as f:
            init = pickle.load(f)
            return init.initialization()
    except FileNotFoundError:
        print('未找到初始化系统的文件')
        raise FileNotFoundError


def SysInitialization() -> FileSystem:
    try:
        return LoadSys()
    except FileNotFoundError:
        try:
            time.sleep(0.5)
            sys = LoadInit()
            print('找到系统的初始化文件\n是否使用此文件进行初始化？')
            flag = input('（y 或 Y -> 是；其他 -> 否）')
            if flag.lower() != 'y':
                time.sleep(0.5)
                print('将使用一个空的文件系统')
                return FileSystem()
            return sys
        except FileNotFoundError:
            time.sleep(0.5)
            print('将使用一个空的文件系统')
            return FileSystem()


def interactive(input_list: list, cmd: CMD) -> bool:
    # 查看帮助信息
    if input_list[0] == 'h':
        cmd.H()

    # 新建空文件
    elif input_list[0] == 'touch':
        if len(input_list) != 2:
            print('请输入正确的文件名')
            return False
        cmd.Touch(input_list[1])

    # 删除文件/目录
    elif input_list[0] == 'rm':
        if len(input_list) != 2:
            print('请输入正确的文件名')
            return False
        cmd.Rm(input_list[1])

    # 查看子目录和文件信息
    elif input_list[0] == 'ls':
        if len(input_list) != 1:
            print('只支持查看本目录中的文件和目录信息')
            return False
        cmd.Ls()

    # 新建目录
    elif input_list[0] == 'mkdir':
        if len(input_list) != 2:
            print('请输入正确的目录名')
            return False
        cmd.Mkdir(input_list[1])

    # 递归移除目录
    elif input_list[0] == 'rmdir':
        if len(input_list) != 2:
            print('请输入正确的目录名')
            return False
        cmd.Rmdir(input_list[1])

    # 进入 子目录/根目录
    elif input_list[0] == 'cd':
        # 子目录
        if len(input_list) == 2:
            cmd.Cd(input_list[1])
        # 根目录
        elif len(input_list) == 1:
            cmd.Cd()
        # 非法
        else:
            print('请输入正确的目录名')
            return False

    # 输出/追加/覆盖 文件内容
    elif input_list[0] == 'cat':
        cmd.Cat(input_list[1:])

    # 查看空间使用情况
    elif input_list[0] == 'disk':
        if len(input_list) != 1:
            print('非法输入')
            return False
        cmd.Disk()

    # 退出
    elif input_list[0] == 'exit':
        print('Bye!')
        QUIT()
        return True

    return False

def main():
    """此文件系统的主函数，包括保存、交互等"""
    sys_lch = SysInitialization()
    cmd = CMD(sys_lch)
    print('\n\n')

    cmd.H()
    print('\n   欢迎！\n\n')

    # 死循环执行交互
    while True:
        print(Decode(cmd.sys.CtDir.name), '# ', end='')
        Input = input()
        Input_list = Input.split()

        # 判断输入情况
        if len(Input_list) == 0:
            continue
        if Input_list[0] not in cmd.command.keys():
            print('没有找到命令')
            continue

        # 根据输入执行对应函数
        if interactive(Input_list, cmd):
            break

    # 保存此次执行情况
    SaveSys(sys_lch)


if __name__ == '__main__':
    main()

