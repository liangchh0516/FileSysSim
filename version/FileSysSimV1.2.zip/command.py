from __future__ import annotations
from basic import File, FileSystem, Dir, HELP_MSG, FillStr, Encode, Decode


NAME_SIZE_LIMIT = 8


class CMD:
    command = {
        'h': '查看帮助',
        'touch': '新建一个空的文件并命名',
        'rm': '删除某个文件或目录',
        'ls': '查看当前目录下文件和目录',
        'mkdir': '新建目录',
        'rmdir': '移除目录',
        'cd': '进入某个子目录 或 回到根目录',
        'cat': '输出/追加/覆盖 文件内容',
        'disk': '查看磁盘剩余空间',
        'exit': '退出系统'
    }

    def __init__(self, other: FileSystem):
        self.sys = other

    def H(self):
        """输出帮助信息"""
        print(HELP_MSG)
        print("本系统包含以下基本命令：")
        print('\n'.join([FillStr(s, 6, ' ') + ': ' + self.command[s] for s in self.command.keys()]))

    def Touch(self, name: str) -> None:
        """新建一个空文件并命名"""
        name_bin = Encode(name)
        if CheckInput(self, name_bin):
            NewFile = File(name_bin)
            self.sys.CtDir.son.append(NewFile)

    def Rm(self, name: str) -> None:
        """删除某个文件或目录"""
        RemoveFromDir(Encode(name), self.sys.CtDir, self)

    def Ls(self):
        """查看目录下文件和目录"""
        print('-权限-  --名称--  ----最近修改时间----  --大小--')
        for obj in self.sys.CtDir.son:
            # 目录，直接输出
            if obj.type == Encode('dir'):
                print('d---     ' + Decode(obj.name))
                continue
            # 文件，输出权限 + 名称 + 最后修改时间
            print(FillStr(File.FilePower[obj.power], 8, ' ')
                  + FillStr(Decode(obj.name), 9, ' ')
                  + FillStr(Decode(obj.LastTime), 20, ' ')
                  + FillStr(str(obj.size), 9, ' ', 0))

    def Mkdir(self, name: str) -> None:
        """新建一个目录"""
        name_bin = Encode(name)
        if CheckInput(self, name_bin):
            NewDir = Dir(name_bin)
            NewDir.AssignFather(self.sys.CtDir)
            self.sys.CtDir.son.append(NewDir)

    def Rmdir(self, name: str):
        """递归删除当前目录的一个子目录"""

        print(f'这个操作将删除 {name} 以及此目录下的所有文件和目录，是否继续？\n'
              'y or Y -> 继续；其他 -> 退出')
        flag = input()
        if flag.lower() != 'y':
            print('退出删除操作')
            return

        # 找到要递归删除的目录
        name_bin = Encode(name)
        DelDir = self.sys.CtDir.GetSonFromName(name_bin)
        if DelDir == -1:
            print('当前目录中未找到目标目录')
            return
        if DelDir.type == Encode('file'):
            print('这是一个文件')
            return

        # 采用压栈出栈的方式遍历全部子目录和子目录中的文件
        # 后序遍历，即 子节点1 -> 子节点2 -> ... -> 子节点n -> 根节点
        stack = [DelDir]
        while len(stack) > 0:
            trans_root = stack[len(stack) - 1]

            # 取出了所有子目录和子文件，出栈
            if len(trans_root.son) == 0:
                RemoveFromDir(trans_root.name, trans_root.father, self)
                stack.pop(len(stack) - 1)
                continue

            for obj in trans_root.son:
                # 目录下是文件，直接删除
                if obj.type == Encode('file'):
                    RemoveFromDir(obj.name, trans_root, self)
                else:
                    # 不是文件但是为空目录，直接删除
                    if len(obj.son) == 0:
                        RemoveFromDir(obj.name, trans_root, self)
                    # 是有子文件或子目录的目录，压栈
                    else:
                        stack.append(obj)
                        break

    def Cd(self, name: str = None) -> None:
        """进入某个目录"""
        # 为空，进入根目录
        if name is None:
            self.sys.CtDir = self.sys.RootDir
            return

        # 不为空，判断是否有子目录并进入
        name_bin = Encode(name)
        SonDir = self.sys.CtDir.GetSonFromName(name_bin)
        if SonDir == -1:
            print('未找到目录')
            return
        if SonDir.type == Encode('file'):
            print(name + '是一个文件')
            return
        self.sys.CtDir = SonDir

    def Cat(self, param_list: list):
        """查看文件/覆盖、追加写入"""
        # 覆盖或追加
        if len(param_list) == 3:
            if type(param_list[0]) != str:
                print('非法输入')
            else:
                # 覆盖
                if param_list[1] == ">":
                    obj = self.sys.CtDir.GetSonFromName(Encode(param_list[2]))
                    if obj == -1:
                        print('没有找到文件')
                    elif obj.type == Encode('dir'):
                        print('这是一个目录，无法读取')
                    else:
                        obj.DeleteF(self.sys)
                        obj.WriteF(self.sys, param_list[0])
                # 追加
                elif param_list[1] == ">>":
                    obj = self.sys.CtDir.GetSonFromName(Encode(param_list[2]))
                    if obj == -1:
                        print('没有找到文件')
                    elif obj.type == Encode('dir'):
                        print('这是一个目录，无法读取')
                    else:
                        str_old = obj.ReadF(self.sys)
                        obj.DeleteF(self.sys)
                        obj.WriteF(self.sys, str_old + param_list[0])
                else:
                    print('非法输入')
        # 查看文件内容
        elif len(param_list) == 1 and type(param_list[0]) == str:
            obj = self.sys.CtDir.GetSonFromName(Encode(param_list[0]))
            if obj == -1:
                print('没有找到文件')
            elif obj.type == Encode('dir'):
                print('这是一个目录，无法读取')
            else:
                print(obj.ReadF(self.sys))
        else:
            print('非法输入')

    def Disk(self) -> None:
        """查看存储空间使用情况"""
        used, remain = self.sys.disk()
        print(f'空间使用了{str(used * 100)}%，剩余{remain}KB')


def CheckInput(obj: CMD, name_bin: bytes) -> bool:
    """检查输入合法性 以及 是否有重名对象"""
    # 检查输入合法性
    if len(name_bin) > NAME_SIZE_LIMIT:
        print("名称过长，创建失败")
        return False
    # 检查在同一目录是否有同名子节点
    elif obj.sys.CtDir.GetSonFromName(name_bin) != -1:
        print("名称重复，创建失败")
        return False
    return True


def RemoveFromDir(tg_name: bytes, tg_dir: Dir, cdm: CMD) -> None:
    son = tg_dir.Delete(tg_name)
    if type(son) == str:
        # 删除失败
        print(son)
        return
    if son.address is None:
        del son
        print(Decode(tg_name) + ' 删除成功')
        return
    son.DeleteF(cdm.sys)
    print(Decode(tg_name) + ' 删除成功')


def SpiltLine():
    print('---------------------------------')


def Test():
    # 这是一个函数测试用例
    sys_lch = FileSystem()
    cmd_lch = CMD(sys_lch)
    SpiltLine()
    cmd_lch.Disk()
    cmd_lch.Mkdir('1')
    cmd_lch.Mkdir('2')
    cmd_lch.Cd('1')
    cmd_lch.Touch('1')
    SpiltLine()
    cmd_lch.Cat(['1234567890' * 3000, '>', '1'])
    SpiltLine()
    cmd_lch.Mkdir('1')
    SpiltLine()
    cmd_lch.Disk()
    SpiltLine()
    cmd_lch.Ls()
    SpiltLine()
    cmd_lch.Cat(['1'])
    SpiltLine()
    cmd_lch.Rm('1')
    SpiltLine()
    cmd_lch.Cat(['1'])
    SpiltLine()
    cmd_lch.Mkdir('dir1')
    cmd_lch.Cat(['dir1'])
    SpiltLine()
    cmd_lch.Cd('dir1')
    cmd_lch.Touch('file1')
    cmd_lch.Cat(['111', '>', 'file1'])
    cmd_lch.Cat(['file1'])
    SpiltLine()
    cmd_lch.Cat(['222', '>>', 'file1'])
    cmd_lch.Cat(['file1'])
    SpiltLine()
    cmd_lch.Cat(['333', '>', 'file1'])
    cmd_lch.Cat(['file1'])
    SpiltLine()
    cmd_lch.Cd()
    cmd_lch.Rmdir('1')
    cmd_lch.Ls()
    SpiltLine()
    cmd_lch.Disk()
    SpiltLine()


if __name__ == '__main__':
    print('这是文件系统的所有用户级操作, 运行此文件用于测试函数')
    Test()
