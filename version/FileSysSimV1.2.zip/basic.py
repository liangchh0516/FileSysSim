from __future__ import annotations
import time
import math
import threading

# 64 * 1024个块，一个块大小为256B，总共16MB
BLOCK_AMT = 64 * 1024 - 2
BLOCK_SIZE = 256

# 64 * 1024个块只需 16位来标识，这里使用FAT16(16位FAT）
# 0x0000            未分配
# 0x0001 ~ 0xFFFE   已分配
# 0xFFFF            文件结束符
# 舍去了 一头一尾 两个块
BLOCK_STR = 1
BLOCK_END = 0xFFFE
FAT_END_FLAG = 'FFFF'
FAT_ENTRY_SIZE = 4

HELP_MSG = f"这是 操作系统课程设计实验课 试验11 的 模拟文件系统\n" \
           f"使用位示图管理内存空间，FAT表记录文件映射\n" \
           f"每一个块大小为{BLOCK_SIZE}B，有{BLOCK_AMT}个块，总共{round((BLOCK_SIZE * BLOCK_AMT) / (1024 * 1024), 2)}M大小"

# 写锁
# 请求 .acquire()
# 释放 .release()
WriteLock = threading.Lock()


class FAT:
    """
    创建FAT表，包括方法:
        AddEntry -> 增加表项\n
        AddEndFlag -> 增加文件结束标志\n
        ReadEntry -> 从指定位置读取表项\n
        DelEntry -> 从指定位置删除表项\n
        FindEntry -> 从头开始寻找表项\n
        DelFile -> 从文件记录首表项开始删除文件信息
    """
    def __init__(self):
        self.FAT = FAT_END_FLAG

    def AddEntry(self, s: str):
        """在表的末尾添加表项"""
        self.FAT += FillStr(s, 4, '0', 0)

    def AddEndFlag(self):
        """在表的末尾添加结束标志"""
        self.FAT += FAT_END_FLAG

    def ReadEntry(self, place: int) -> str:
        """读取指定位置表项"""
        return self.FAT[place: place + FAT_ENTRY_SIZE]

    def DelEntry(self, place: int):
        """删除指定位置表项"""
        self.FAT = self.FAT[: place] + self.FAT[place + 4:]

    def FindEntry(self, block_str: str) -> (bool | int):
        """从表头开始寻找指定表项"""
        place = 0
        while self.ReadEntry(place) != block_str:
            # 没找到
            if place == len(self.FAT):
                return False
            place += FAT_ENTRY_SIZE
        return place

    def DelFile(self, first_block: str) -> (bool | list):
        """从first_block开始，删除所有FAT表信息，直到下一个结束符"""
        # 找到文件对应FAT表对应位置
        place = self.FindEntry(FillStr(first_block, 4, '0', 0))
        if place is False:
            return place

        # 删除信息
        storage_list = []
        while True:
            STO_place_hex = self.ReadEntry(place)
            self.DelEntry(place)
            storage_list.append(HexStrToInt(STO_place_hex))
            if STO_place_hex == FAT_END_FLAG:
                return storage_list


class BitMap:
    """
    创建位示图，包括方法：
        GetEmptyBlock -> 获得一个盘块为空的盘块号\n
        EmptyBlockAMT -> 获得所有为空的盘块数\n
        Write -> 写入指定盘块位示图\n
        Read -> 读取指定盘块位示图\n
        RemainDisk -> 获取空间使用量\n
    """
    def __init__(self):
        self.BitMap = {i: 0 for i in range(BLOCK_STR, BLOCK_END + 1)}

    def GetEmptyBlock(self) -> int:
        """
        每次找到一个空闲的块，并返回块号\n
        若没有空闲的块则返回 -1
        """
        if 0 not in self.BitMap.values():
            return -1

        for i in range(BLOCK_STR, BLOCK_END + 1):
            if self.BitMap[i] == 0:
                return i

    def EmptyBlockAMT(self) -> int:
        """返回空闲盘块的数量"""
        return list(self.BitMap.values()).count(0)

    def Write(self, block_num: int, data: int):
        """写入指定盘块位示图"""
        self.BitMap[block_num] = data

    def Read(self, block_num: int) -> int:
        """读取指定盘块位示图"""
        return self.BitMap[block_num]

    def RemainDisk(self) -> float:
        """获取磁盘使用量"""
        return round((1 - (self.EmptyBlockAMT() / BLOCK_END - BLOCK_STR + 1)), 4)


class Storage:
    """
    虚拟存储空间的创建，包括方法：
        Write -> 将指定数据写入指定盘块号中\n
        Read -> 读取指定盘块号数据\n
    """
    def __init__(self):
        self.Storage = {i: None for i in range(BLOCK_STR, BLOCK_END + 1)}

    def Write(self, block_num: int, data):
        """将数据写入指定盘块号中"""
        self.Storage[block_num] = data

    def Read(self, block_num: int) -> (bytes | bool):
        """读取指定盘块号数据"""
        data = self.Storage[block_num]
        return data if data is not None else False


class Dir:
    """
    创建一个新的目录，包括

    属性：
        name(bytes) -> 目录名\n
        father(Dir) -> 父目录\n
        son(Dir) -> 子目录/文件\n
        type(bytes) -> 类型\n

    方法：
        AssignFather -> 指定父目录\n
        AddSon -> 添加子目录\n
        GetSonFromName -> 根据指定名称找到子目录/文件\n
        DelSon -> 删除指定子目录/文件的映射关系\n
        Delete -> 删除空的子目录或者子文件\n
    """

    def __init__(self, dirname: bytes):
        self.name = dirname
        self.father = None
        self.son = []
        self.type = Encode('dir')

    def AssignFather(self, father: Dir):
        """为此目录指定父目录"""
        self.father = father

    def AddSon(self, other: (Dir | File)):
        """增加此目录下文件或目录"""
        self.son.append(other)

    def GetSonFromName(self, name: bytes) -> (Dir | File | int):
        """遍历儿子节点，返回符合要求的对象"""
        for elm in self.son:
            if elm.name == name:
                return elm
        else:
            return -1

    def DelSon(self, obj: (Dir | File)):
        """此目录下文件或目录的映射关系"""
        self.son.remove(obj)

    def Delete(self, name: bytes) -> (str | File):
        """删除此目录下文件或空目录"""
        son = self.GetSonFromName(name)
        if son == -1:
            return '没有那个文件或者目录'

        # 删除的是目录
        if son.type == Encode('dir'):
            if len(son.son) != 0:
                return '文件夹不为空，无法删除，尝试使用命令 rmdir ' + Decode(name)
            self.DelSon(son)
            return '成功删除'
        # 删除的是文件
        else:
            self.DelSon(son)
            return son


class FileSystem:
    """
    创建文件系统，包括

    属性：
        BitMap(BitMap) -> 位示图\n
        Storage（Storage） -> 存储空间\n
        FAT（FAT） -> FAT表\n
        RootDir -> 根目录\n
        CtDir -> 当前目录\n

    方法：
        WriteToBlock -> 将数据写入指定盘块中\n
        Write -> 写入指定数据\n
        ReadFromBlock -> 读取指定盘块号中的内容\n
        Read -> 根据FAT表读取盘块中内容\n
        Delete -> 根据输入的盘块号删除存储空间中内容\n
        disk -> 获得存储空间使用量、剩余空间大小\n
    """

    def __init__(self):
        """文件系统初始化"""
        self.BitMap = BitMap()  # 创建位示图
        self.Storage = Storage()  # 创建存储
        self.FAT = FAT()  # 创建FAT表
        self.RootDir = Dir(Encode('home'))  # 创建根目录
        self.CtDir = self.RootDir  # 当前目录

    def WriteToBlock(self, block_num: int, data: bytes):
        """
        将数据写入指定盘块中

        :param block_num: 要写入的盘块号
        :param data: 要写入的数据
        """
        # 写入数据
        self.Storage.Write(block_num, data)
        # 将位示图对应标签置1
        self.BitMap.Write(block_num, 1)
        # 更新FAT表
        self.FAT.AddEntry(IntToHexStr(block_num))

    def Write(self, data: str) -> (int, int):
        """
        写入指定数据，返回写入的第一个盘块号

        若盘块数不足则返回-1，写入出错返回0
        :param data: 要写入的数据
        :return: 写入的第一个盘块号
        """
        # 将要写入的数据以 utf-8 编码
        # 例：'你aa'.encode('utf-8') = b'\xe4\xbd\xa0aa' 占5字节
        bin_data = data.encode('utf-8')
        # 计算需要的盘块数
        block_amt = math.ceil(len(bin_data) / BLOCK_SIZE)

        # 判断剩下的盘块是否够用
        if block_amt > self.BitMap.EmptyBlockAMT():
            return -1, -1

        # 分盘块写入数据，不满一块算占一块盘块
        # 一个文件的写入是一个不可分的操作，需要写锁
        first_block_num = 0
        AcquireLock()
        for block_write in range(block_amt):
            # 前面要写入盘块的数据
            if block_write < block_amt - 1:
                # 找到首个写入盘块的盘块号
                if block_write == 0:
                    first_block_num = self.BitMap.GetEmptyBlock()
                self.WriteToBlock(self.BitMap.GetEmptyBlock(), bin_data[block_write * BLOCK_SIZE:
                                                                        (block_write + 1) * BLOCK_SIZE])
            # 最后一个要写入盘块的数据（可能不满BLOCK_SIZE大小）
            else:
                if block_write == 0:
                    first_block_num = self.BitMap.GetEmptyBlock()
                self.WriteToBlock(self.BitMap.GetEmptyBlock(), bin_data[block_write * BLOCK_SIZE:])
                # FAT表中添加文件结束符
                self.FAT.AddEndFlag()
        ReleaseLock()

        # 返回第一个存储盘块号 和 文件大小
        return first_block_num, len(bin_data)

    def ReadFromBlock(self, block_num: int) -> (bytes | bool):
        """
        读取指定盘块号中的内容，若盘块号未被写入则返回False

        :param block_num: 需要读取的盘块号
        :return: False 或 盘块内容
        """
        # 未被写入
        if self.BitMap.Read(block_num) == 0:
            return False
        # 被写入，返回盘块中内容
        return self.Storage.Read(block_num)

    def Read(self, first_block: str) -> str:
        """
        根据输入的首盘块号开始读取 FAT 表，直到读到 ’FFFF‘
        :param first_block: 首盘块号
        :return: 读取的文件内容
        """
        # 找到盘块号对应的FAT表位置
        place = self.FAT.FindEntry(FillStr(first_block, 4, '0', 0))

        if place is False:
            print('读取失败')
            return ''

        # 读取文件内容
        data_bin = b''
        while True:
            STO_place = self.FAT.ReadEntry(place)
            # 读到了结束符
            if STO_place == FAT_END_FLAG:
                return Decode(data_bin)
            # 连接二进制数据
            data_bin += self.ReadFromBlock(HexStrToInt(STO_place))
            place += FAT_ENTRY_SIZE

    def Delete(self, first_block: str):
        """根据输入的首盘块号删除对应文件内容"""
        # 删除为原子操作，申请写锁
        AcquireLock()

        # 优先删除FAT表并获得存储数据的位置信息
        STO_list = self.FAT.DelFile(first_block)
        for STO_place in STO_list:
            self.BitMap.Write(STO_place, 0)
            # 此处是否将存储空间置空结果不变
            # self.Storage.Write(STO_place, None)

        ReleaseLock()

    def disk(self) -> (float, float):
        """返回存储空间使用量，剩余空间大小（KB）"""
        return self.BitMap.RemainDisk(), self.BitMap.EmptyBlockAMT() / 4


class File:
    """
    文件的类（union表），包括

    属性：
        name(int) -> 文件名\n
        power(int) -> 文件权限\n
        size(int) -> 文件大小\n
        LastTime(str) -> 最后修改时间\n
        address(str) -> 内存储存首盘块号
    方法：
        CoverFile -> 覆盖写入\n
        ChangeFilePower -> 修改权限\n
        ReadF -> 查看文件内容
    """
    FilePower = {1: '-r--', 2: '-w--', 3: '-rw-', 4: '---x', 5: '-r-x', 6: '--wx', 7: '-rwx'}

    def __init__(self, filename: bytes):
        self.name = filename
        self.address = None
        self.LastTime = GetCurrentTime()
        self.power = 3
        self.size = 0
        self.type = Encode('file')

    def DeleteF(self, other: FileSystem):
        """删除文件及其对应存储信息"""
        if self.address is None:
            return
        other.Delete(self.address)

    def WriteF(self, other: FileSystem, content: str):
        """
        覆盖写入文件

        :param other: 文件系统类的对象
        :param content: 写入的内容
        """
        first_block_num, size = other.Write(content)
        if first_block_num == -1:
            print('存储空间不足！无法写入！')
        elif first_block_num == 0:
            print('未知写入错误！')
        else:
            # 记录 修改时间、存储第一盘块号、文件大小
            self.LastTime = GetCurrentTime()
            self.address = IntToHexStr(first_block_num)
            self.size = size

    def ChangeFilePower(self, power: int):
        """修改文件权限为power"""
        # 保证输入的正确性
        if power not in self.FilePower.keys():
            print(f'请输入正确的数字:{self.FilePower.keys()}')
            return

        self.power = power

    def ReadF(self, other: FileSystem) -> str:
        """查看文件内容"""
        if self.address is None:
            return '文件为空，无内容读取！'
        return other.Read(self.address)


def IntToHexStr(num: int) -> str:
    """将输入的整形数字转换为16进制字符串"""
    return hex(num)[2:].upper()


def HexStrToInt(s: str) -> int:
    """将输入的16进制字符串转换为整形数字"""
    return int(s, 16)


def GetCurrentTime() -> bytes:
    """返回当前时间"""
    current_time = time.localtime()
    return Encode(time.strftime("%Y-%m-%d %H:%M:%S", current_time))


def Encode(s: str) -> bytes:
    """返回字符串UTF-8编码"""
    return s.encode('utf-8')


def Decode(binary: bytes) -> str:
    """返回二进制对应UTF-8编码字符串"""
    return binary.decode()


def AcquireLock():
    """请求锁"""
    WriteLock.acquire()


def ReleaseLock():
    """释放锁"""
    WriteLock.release()


def FillStr(str1: str, length: int, str2: str, flag=1) -> str:
    """用str2填充str1至length，默认从后填充，flag=0从前填充"""
    n = math.ceil((length - len(str1)) / len(str2))
    if flag == 1:
        NewStr = str1 + str2 * n
        return NewStr[:length]
    NewStr = str2 * n + str1
    return NewStr[-length:]


if __name__ == '__main__':
    print('这是文件系统的底层配置')
